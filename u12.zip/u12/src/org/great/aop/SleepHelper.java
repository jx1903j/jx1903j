package org.great.aop;

import java.lang.reflect.Method;

import org.springframework.aop.AfterReturningAdvice;
import org.springframework.aop.MethodBeforeAdvice;

/**
 * 定义一个睡眠的通知（增强） 同时实现前置 和后置
 */
public class SleepHelper implements MethodBeforeAdvice, AfterReturningAdvice {

	public void afterReturning(Object returnValue, Method method,
			Object[] args, Object target) throws Throwable {
		System.out.println("睡觉后要做美梦");
	}

	public void before(Method method, Object[] args, Object target)
			throws Throwable {
		System.out.println("睡觉前要敷面膜");

	}

}