package org.great.aop;
/** 
 * 定义一个接口 
 */
public interface Sleepable {
	 /** 
	   * 睡觉方法 
	   */
	  void sleep(); 
}
