package org.great.aop;

/** 
 * 实现类
 * 本人实现睡觉接口 
 */
public class ChenLliNa implements Sleepable { 
  
  public void sleep() { 
    // TODO Auto-generated method stub  
    System.out.println("乖,该睡觉了！"); 
    
    //演示异常增强时启用以下两行
//    String tmp=null;
//    tmp.substring(0);
  } 
} 